from . import reascript_api
from .core.project import Project
from .core.reaper import *

CURRENT_PROJECT = Project(0)
