from . import _api_function

@_api_function
def RPR_AddMediaItemToTrack():
    pass

@_api_function
def RPR_AddProjectMarker():
    pass

@_api_function
def RPR_AddProjectMarker2():
    pass

@_api_function
def RPR_AddRemoveReaScript():
    pass

@_api_function
def RPR_AddTakeToMediaItem():
    pass

@_api_function
def RPR_AddTempoTimeSigMarker():
    pass

@_api_function
def RPR_adjustZoom():
    pass

@_api_function
def RPR_AnyTrackSolo():
    pass

@_api_function
def RPR_APIExists():
    pass

@_api_function
def RPR_APITest():
    pass

@_api_function
def RPR_ApplyNudge():
    pass

@_api_function
def RPR_ArmCommand():
    pass

@_api_function
def RPR_Audio_Init():
    pass

@_api_function
def RPR_Audio_IsPreBuffer():
    pass

@_api_function
def RPR_Audio_IsRunning():
    pass

@_api_function
def RPR_Audio_Quit():
    pass

@_api_function
def RPR_AudioAccessorValidateState():
    pass

@_api_function
def RPR_BypassFxAllTracks():
    pass

@_api_function
def RPR_ClearAllRecArmed():
    pass

@_api_function
def RPR_ClearConsole():
    pass

@_api_function
def RPR_ClearPeakCache():
    pass

@_api_function
def RPR_ColorFromNative():
    pass

@_api_function
def RPR_ColorToNative():
    pass

@_api_function
def RPR_CountAutomationItems():
    pass

@_api_function
def RPR_CountEnvelopePoints():
    pass

@_api_function
def RPR_CountEnvelopePointsEx():
    pass

@_api_function
def RPR_CountMediaItems():
    pass

@_api_function
def RPR_CountProjectMarkers():
    pass

@_api_function
def RPR_CountSelectedMediaItems():
    pass

@_api_function
def RPR_CountSelectedTracks():
    pass

@_api_function
def RPR_CountSelectedTracks2():
    pass

@_api_function
def RPR_CountTakeEnvelopes():
    pass

@_api_function
def RPR_CountTakes():
    pass

@_api_function
def RPR_CountTCPFXParms():
    pass

@_api_function
def RPR_CountTempoTimeSigMarkers():
    pass

@_api_function
def RPR_CountTrackEnvelopes():
    pass

@_api_function
def RPR_CountTrackMediaItems():
    pass

@_api_function
def RPR_CountTracks():
    pass

@_api_function
def RPR_CreateNewMIDIItemInProj():
    pass

@_api_function
def RPR_CreateTakeAudioAccessor():
    pass

@_api_function
def RPR_CreateTrackAudioAccessor():
    pass

@_api_function
def RPR_CreateTrackSend():
    pass

@_api_function
def RPR_CSurf_FlushUndo():
    pass

@_api_function
def RPR_CSurf_GetTouchState():
    pass

@_api_function
def RPR_CSurf_GoEnd():
    pass

@_api_function
def RPR_CSurf_GoStart():
    pass

@_api_function
def RPR_CSurf_NumTracks():
    pass

@_api_function
def RPR_CSurf_OnArrow():
    pass

@_api_function
def RPR_CSurf_OnFwd():
    pass

@_api_function
def RPR_CSurf_OnFXChange():
    pass

@_api_function
def RPR_CSurf_OnInputMonitorChange():
    pass

@_api_function
def RPR_CSurf_OnInputMonitorChangeEx():
    pass

@_api_function
def RPR_CSurf_OnMuteChange():
    pass

@_api_function
def RPR_CSurf_OnMuteChangeEx():
    pass

@_api_function
def RPR_CSurf_OnPanChange():
    pass

@_api_function
def RPR_CSurf_OnPanChangeEx():
    pass

@_api_function
def RPR_CSurf_OnPause():
    pass

@_api_function
def RPR_CSurf_OnPlay():
    pass

@_api_function
def RPR_CSurf_OnPlayRateChange():
    pass

@_api_function
def RPR_CSurf_OnRecArmChange():
    pass

@_api_function
def RPR_CSurf_OnRecArmChangeEx():
    pass

@_api_function
def RPR_CSurf_OnRecord():
    pass

@_api_function
def RPR_CSurf_OnRecvPanChange():
    pass

@_api_function
def RPR_CSurf_OnRecvVolumeChange():
    pass

@_api_function
def RPR_CSurf_OnRew():
    pass

@_api_function
def RPR_CSurf_OnRewFwd():
    pass

@_api_function
def RPR_CSurf_OnScroll():
    pass

@_api_function
def RPR_CSurf_OnSelectedChange():
    pass

@_api_function
def RPR_CSurf_OnSendPanChange():
    pass

@_api_function
def RPR_CSurf_OnSendVolumeChange():
    pass

@_api_function
def RPR_CSurf_OnSoloChange():
    pass

@_api_function
def RPR_CSurf_OnSoloChangeEx():
    pass

@_api_function
def RPR_CSurf_OnStop():
    pass

@_api_function
def RPR_CSurf_OnTempoChange():
    pass

@_api_function
def RPR_CSurf_OnTrackSelection():
    pass

@_api_function
def RPR_CSurf_OnVolumeChange():
    pass

@_api_function
def RPR_CSurf_OnVolumeChangeEx():
    pass

@_api_function
def RPR_CSurf_OnWidthChange():
    pass

@_api_function
def RPR_CSurf_OnWidthChangeEx():
    pass

@_api_function
def RPR_CSurf_OnZoom():
    pass

@_api_function
def RPR_CSurf_ResetAllCachedVolPanStates():
    pass

@_api_function
def RPR_CSurf_ScrubAmt():
    pass

@_api_function
def RPR_CSurf_SetAutoMode():
    pass

@_api_function
def RPR_CSurf_SetPlayState():
    pass

@_api_function
def RPR_CSurf_SetRepeatState():
    pass

@_api_function
def RPR_CSurf_SetSurfaceMute():
    pass

@_api_function
def RPR_CSurf_SetSurfacePan():
    pass

@_api_function
def RPR_CSurf_SetSurfaceRecArm():
    pass

@_api_function
def RPR_CSurf_SetSurfaceSelected():
    pass

@_api_function
def RPR_CSurf_SetSurfaceSolo():
    pass

@_api_function
def RPR_CSurf_SetSurfaceVolume():
    pass

@_api_function
def RPR_CSurf_SetTrackListChange():
    pass

@_api_function
def RPR_CSurf_TrackFromID():
    pass

@_api_function
def RPR_CSurf_TrackToID():
    pass

@_api_function
def RPR_DB2SLIDER():
    pass

@_api_function
def RPR_DeleteEnvelopePointRange():
    pass

@_api_function
def RPR_DeleteEnvelopePointRangeEx():
    pass

@_api_function
def RPR_DeleteExtState():
    pass

@_api_function
def RPR_DeleteProjectMarker():
    pass

@_api_function
def RPR_DeleteProjectMarkerByIndex():
    pass

@_api_function
def RPR_DeleteTakeStretchMarkers():
    pass

@_api_function
def RPR_DeleteTempoTimeSigMarker():
    pass

@_api_function
def RPR_DeleteTrack():
    pass

@_api_function
def RPR_DeleteTrackMediaItem():
    pass

@_api_function
def RPR_DestroyAudioAccessor():
    pass

@_api_function
def RPR_Dock_UpdateDockID():
    pass

@_api_function
def RPR_DockIsChildOfDock():
    pass

@_api_function
def RPR_DockWindowActivate():
    pass

@_api_function
def RPR_DockWindowAdd():
    pass

@_api_function
def RPR_DockWindowAddEx():
    pass

@_api_function
def RPR_DockWindowRefresh():
    pass

@_api_function
def RPR_DockWindowRefreshForHWND():
    pass

@_api_function
def RPR_DockWindowRemove():
    pass

@_api_function
def RPR_EditTempoTimeSigMarker():
    pass

@_api_function
def RPR_EnsureNotCompletelyOffscreen():
    pass

@_api_function
def RPR_EnumerateFiles():
    pass

@_api_function
def RPR_EnumerateSubdirectories():
    pass

@_api_function
def RPR_EnumPitchShiftModes():
    pass

@_api_function
def RPR_EnumPitchShiftSubModes():
    pass

@_api_function
def RPR_EnumProjectMarkers():
    pass

@_api_function
def RPR_EnumProjectMarkers2():
    pass

@_api_function
def RPR_EnumProjectMarkers3():
    pass

@_api_function
def RPR_EnumProjects():
    pass

@_api_function
def RPR_EnumProjExtState():
    pass

@_api_function
def RPR_EnumRegionRenderMatrix():
    pass

@_api_function
def RPR_EnumTrackMIDIProgramNames():
    pass

@_api_function
def RPR_EnumTrackMIDIProgramNamesEx():
    pass

@_api_function
def RPR_Envelope_Evaluate():
    pass

@_api_function
def RPR_Envelope_FormatValue():
    pass

@_api_function
def RPR_Envelope_GetParentTake():
    pass

@_api_function
def RPR_Envelope_GetParentTrack():
    pass

@_api_function
def RPR_Envelope_SortPoints():
    pass

@_api_function
def RPR_Envelope_SortPointsEx():
    pass

@_api_function
def RPR_ExecProcess():
    pass

@_api_function
def RPR_file_exists():
    pass

@_api_function
def RPR_FindTempoTimeSigMarker():
    pass

@_api_function
def RPR_format_timestr():
    pass

@_api_function
def RPR_format_timestr_len():
    pass

@_api_function
def RPR_format_timestr_pos():
    pass

@_api_function
def RPR_genGuid():
    pass

@_api_function
def RPR_get_ini_file():
    pass

@_api_function
def RPR_GetActiveTake():
    pass

@_api_function
def RPR_GetAllProjectPlayStates():
    pass

@_api_function
def RPR_GetAppVersion():
    pass

@_api_function
def RPR_GetArmedCommand():
    pass

@_api_function
def RPR_GetAudioAccessorEndTime():
    pass

@_api_function
def RPR_GetAudioAccessorHash():
    pass

@_api_function
def RPR_GetAudioAccessorSamples():
    pass

@_api_function
def RPR_GetAudioAccessorStartTime():
    pass

@_api_function
def RPR_GetAudioDeviceInfo():
    pass

@_api_function
def RPR_GetConfigWantsDock():
    pass

@_api_function
def RPR_GetCurrentProjectInLoadSave():
    pass

@_api_function
def RPR_GetCursorContext():
    pass

@_api_function
def RPR_GetCursorContext2():
    pass

@_api_function
def RPR_GetCursorPosition():
    pass

@_api_function
def RPR_GetCursorPositionEx():
    pass

@_api_function
def RPR_GetDisplayedMediaItemColor():
    pass

@_api_function
def RPR_GetDisplayedMediaItemColor2():
    pass

@_api_function
def RPR_GetEnvelopeName():
    pass

@_api_function
def RPR_GetEnvelopePoint():
    pass

@_api_function
def RPR_GetEnvelopePointByTime():
    pass

@_api_function
def RPR_GetEnvelopePointByTimeEx():
    pass

@_api_function
def RPR_GetEnvelopePointEx():
    pass

@_api_function
def RPR_GetEnvelopeScalingMode():
    pass

@_api_function
def RPR_GetEnvelopeStateChunk():
    pass

@_api_function
def RPR_GetExePath():
    pass

@_api_function
def RPR_GetExtState():
    pass

@_api_function
def RPR_GetFocusedFX():
    pass

@_api_function
def RPR_GetFreeDiskSpaceForRecordPath():
    pass

@_api_function
def RPR_GetFXEnvelope():
    pass

@_api_function
def RPR_GetGlobalAutomationOverride():
    pass

@_api_function
def RPR_GetHZoomLevel():
    pass

@_api_function
def RPR_GetInputChannelName():
    pass

@_api_function
def RPR_GetInputOutputLatency():
    pass

@_api_function
def RPR_GetItemEditingTime2():
    pass

@_api_function
def RPR_GetItemProjectContext():
    pass

@_api_function
def RPR_GetItemStateChunk():
    pass

@_api_function
def RPR_GetLastColorThemeFile():
    pass

@_api_function
def RPR_GetLastMarkerAndCurRegion():
    pass

@_api_function
def RPR_GetLastTouchedFX():
    pass

@_api_function
def RPR_GetLastTouchedTrack():
    pass

@_api_function
def RPR_GetMainHwnd():
    pass

@_api_function
def RPR_GetMasterMuteSoloFlags():
    pass

@_api_function
def RPR_GetMasterTrack():
    pass

@_api_function
def RPR_GetMasterTrackVisibility():
    pass

@_api_function
def RPR_GetMaxMidiInputs():
    pass

@_api_function
def RPR_GetMaxMidiOutputs():
    pass

@_api_function
def RPR_GetMediaItem():
    pass

@_api_function
def RPR_GetMediaItem_Track():
    pass

@_api_function
def RPR_GetMediaItemInfo_Value():
    pass

@_api_function
def RPR_GetMediaItemNumTakes():
    pass

@_api_function
def RPR_GetMediaItemTake():
    pass

@_api_function
def RPR_GetMediaItemTake_Item():
    pass

@_api_function
def RPR_GetMediaItemTake_Peaks():
    pass

@_api_function
def RPR_GetMediaItemTake_Source():
    pass

@_api_function
def RPR_GetMediaItemTake_Track():
    pass

@_api_function
def RPR_GetMediaItemTakeByGUID():
    pass

@_api_function
def RPR_GetMediaItemTakeInfo_Value():
    pass

@_api_function
def RPR_GetMediaItemTrack():
    pass

@_api_function
def RPR_GetMediaSourceFileName():
    pass

@_api_function
def RPR_GetMediaSourceLength():
    pass

@_api_function
def RPR_GetMediaSourceNumChannels():
    pass

@_api_function
def RPR_GetMediaSourceParent():
    pass

@_api_function
def RPR_GetMediaSourceSampleRate():
    pass

@_api_function
def RPR_GetMediaSourceType():
    pass

@_api_function
def RPR_GetMediaTrackInfo_Value():
    pass

@_api_function
def RPR_GetMIDIInputName():
    pass

@_api_function
def RPR_GetMIDIOutputName():
    pass

@_api_function
def RPR_GetMixerScroll():
    pass

@_api_function
def RPR_GetMouseModifier():
    pass

@_api_function
def RPR_GetMousePosition():
    pass

@_api_function
def RPR_GetNumAudioInputs():
    pass

@_api_function
def RPR_GetNumAudioOutputs():
    pass

@_api_function
def RPR_GetNumMIDIInputs():
    pass

@_api_function
def RPR_GetNumMIDIOutputs():
    pass

@_api_function
def RPR_GetNumTracks():
    pass

@_api_function
def RPR_GetOS():
    pass

@_api_function
def RPR_GetOutputChannelName():
    pass

@_api_function
def RPR_GetOutputLatency():
    pass

@_api_function
def RPR_GetParentTrack():
    pass

@_api_function
def RPR_GetPeakFileName():
    pass

@_api_function
def RPR_GetPeakFileNameEx():
    pass

@_api_function
def RPR_GetPeakFileNameEx2():
    pass

@_api_function
def RPR_GetPlayPosition():
    pass

@_api_function
def RPR_GetPlayPosition2():
    pass

@_api_function
def RPR_GetPlayPosition2Ex():
    pass

@_api_function
def RPR_GetPlayPositionEx():
    pass

@_api_function
def RPR_GetPlayState():
    pass

@_api_function
def RPR_GetPlayStateEx():
    pass

@_api_function
def RPR_GetProjectLength():
    pass

@_api_function
def RPR_GetProjectName():
    pass

@_api_function
def RPR_GetProjectPath():
    pass

@_api_function
def RPR_GetProjectPathEx():
    pass

@_api_function
def RPR_GetProjectStateChangeCount():
    pass

@_api_function
def RPR_GetProjectTimeOffset():
    pass

@_api_function
def RPR_GetProjectTimeSignature():
    pass

@_api_function
def RPR_GetProjectTimeSignature2():
    pass

@_api_function
def RPR_GetProjExtState():
    pass

@_api_function
def RPR_GetResourcePath():
    pass

@_api_function
def RPR_GetSelectedEnvelope():
    pass

@_api_function
def RPR_GetSelectedMediaItem():
    pass

@_api_function
def RPR_GetSelectedTrack():
    pass

@_api_function
def RPR_GetSelectedTrack2():
    pass

@_api_function
def RPR_GetSelectedTrackEnvelope():
    pass

@_api_function
def RPR_GetSet_ArrangeView2():
    pass

@_api_function
def RPR_GetSet_LoopTimeRange():
    pass

@_api_function
def RPR_GetSet_LoopTimeRange2():
    pass

@_api_function
def RPR_GetSetAutomationItemInfo():
    pass

@_api_function
def RPR_GetSetEnvelopeState():
    pass

@_api_function
def RPR_GetSetEnvelopeState2():
    pass

@_api_function
def RPR_GetSetItemState():
    pass

@_api_function
def RPR_GetSetItemState2():
    pass

@_api_function
def RPR_GetSetMediaItemInfo_String():
    pass

@_api_function
def RPR_GetSetMediaItemTakeInfo_String():
    pass

@_api_function
def RPR_GetSetMediaTrackInfo_String():
    pass

@_api_function
def RPR_GetSetProjectAuthor():
    pass

@_api_function
def RPR_GetSetProjectGrid():
    pass

@_api_function
def RPR_GetSetProjectNotes():
    pass

@_api_function
def RPR_GetSetRepeat():
    pass

@_api_function
def RPR_GetSetRepeatEx():
    pass

@_api_function
def RPR_GetSetTrackGroupMembership():
    pass

@_api_function
def RPR_GetSetTrackGroupMembershipHigh():
    pass

@_api_function
def RPR_GetSetTrackState():
    pass

@_api_function
def RPR_GetSetTrackState2():
    pass

@_api_function
def RPR_GetSubProjectFromSource():
    pass

@_api_function
def RPR_GetTake():
    pass

@_api_function
def RPR_GetTakeEnvelope():
    pass

@_api_function
def RPR_GetTakeEnvelopeByName():
    pass

@_api_function
def RPR_GetTakeName():
    pass

@_api_function
def RPR_GetTakeNumStretchMarkers():
    pass

@_api_function
def RPR_GetTakeStretchMarker():
    pass

@_api_function
def RPR_GetTakeStretchMarkerSlope():
    pass

@_api_function
def RPR_GetTCPFXParm():
    pass

@_api_function
def RPR_GetTempoMatchPlayRate():
    pass

@_api_function
def RPR_GetTempoTimeSigMarker():
    pass

@_api_function
def RPR_GetToggleCommandState():
    pass

@_api_function
def RPR_GetToggleCommandStateEx():
    pass

@_api_function
def RPR_GetTooltipWindow():
    pass

@_api_function
def RPR_GetTrack():
    pass

@_api_function
def RPR_GetTrackAutomationMode():
    pass

@_api_function
def RPR_GetTrackColor():
    pass

@_api_function
def RPR_GetTrackDepth():
    pass

@_api_function
def RPR_GetTrackEnvelope():
    pass

@_api_function
def RPR_GetTrackEnvelopeByChunkName():
    pass

@_api_function
def RPR_GetTrackEnvelopeByName():
    pass

@_api_function
def RPR_GetTrackGUID():
    pass

@_api_function
def RPR_GetTrackMediaItem():
    pass

@_api_function
def RPR_GetTrackMIDILyrics():
    pass

@_api_function
def RPR_GetTrackMIDINoteName():
    pass

@_api_function
def RPR_GetTrackMIDINoteNameEx():
    pass

@_api_function
def RPR_GetTrackMIDINoteRange():
    pass

@_api_function
def RPR_GetTrackName():
    pass

@_api_function
def RPR_GetTrackNumMediaItems():
    pass

@_api_function
def RPR_GetTrackNumSends():
    pass

@_api_function
def RPR_GetTrackReceiveName():
    pass

@_api_function
def RPR_GetTrackReceiveUIMute():
    pass

@_api_function
def RPR_GetTrackReceiveUIVolPan():
    pass

@_api_function
def RPR_GetTrackSendInfo_Value():
    pass

@_api_function
def RPR_GetTrackSendName():
    pass

@_api_function
def RPR_GetTrackSendUIMute():
    pass

@_api_function
def RPR_GetTrackSendUIVolPan():
    pass

@_api_function
def RPR_GetTrackState():
    pass

@_api_function
def RPR_GetTrackStateChunk():
    pass

@_api_function
def RPR_GetTrackUIMute():
    pass

@_api_function
def RPR_GetTrackUIPan():
    pass

@_api_function
def RPR_GetTrackUIVolPan():
    pass

@_api_function
def RPR_GetUnderrunTime():
    pass

@_api_function
def RPR_GetUserFileNameForRead():
    pass

@_api_function
def RPR_GetUserInputs():
    pass

@_api_function
def RPR_GoToMarker():
    pass

@_api_function
def RPR_GoToRegion():
    pass

@_api_function
def RPR_GR_SelectColor():
    pass

@_api_function
def RPR_GSC_mainwnd():
    pass

@_api_function
def RPR_guidToString():
    pass

@_api_function
def RPR_HasExtState():
    pass

@_api_function
def RPR_HasTrackMIDIPrograms():
    pass

@_api_function
def RPR_HasTrackMIDIProgramsEx():
    pass

@_api_function
def RPR_Help_Set():
    pass

@_api_function
def RPR_image_resolve_fn():
    pass

@_api_function
def RPR_InsertAutomationItem():
    pass

@_api_function
def RPR_InsertEnvelopePoint():
    pass

@_api_function
def RPR_InsertEnvelopePointEx():
    pass

@_api_function
def RPR_InsertMedia():
    pass

@_api_function
def RPR_InsertMediaSection():
    pass

@_api_function
def RPR_InsertTrackAtIndex():
    pass

@_api_function
def RPR_IsMediaExtension():
    pass

@_api_function
def RPR_IsMediaItemSelected():
    pass

@_api_function
def RPR_IsProjectDirty():
    pass

@_api_function
def RPR_IsTrackSelected():
    pass

@_api_function
def RPR_IsTrackVisible():
    pass

@_api_function
def RPR_joystick_create():
    pass

@_api_function
def RPR_joystick_destroy():
    pass

@_api_function
def RPR_joystick_enum():
    pass

@_api_function
def RPR_joystick_getaxis():
    pass

@_api_function
def RPR_joystick_getbuttonmask():
    pass

@_api_function
def RPR_joystick_getinfo():
    pass

@_api_function
def RPR_joystick_getpov():
    pass

@_api_function
def RPR_joystick_update():
    pass

@_api_function
def RPR_LICE_ClipLine():
    pass

@_api_function
def RPR_Loop_OnArrow():
    pass

@_api_function
def RPR_Main_OnCommand():
    pass

@_api_function
def RPR_Main_OnCommandEx():
    pass

@_api_function
def RPR_Main_openProject():
    pass

@_api_function
def RPR_Main_SaveProject():
    pass

@_api_function
def RPR_Main_UpdateLoopInfo():
    pass

@_api_function
def RPR_MarkProjectDirty():
    pass

@_api_function
def RPR_MarkTrackItemsDirty():
    pass

@_api_function
def RPR_Master_GetPlayRate():
    pass

@_api_function
def RPR_Master_GetPlayRateAtTime():
    pass

@_api_function
def RPR_Master_GetTempo():
    pass

@_api_function
def RPR_Master_NormalizePlayRate():
    pass

@_api_function
def RPR_Master_NormalizeTempo():
    pass

@_api_function
def RPR_MB():
    pass

@_api_function
def RPR_MediaItemDescendsFromTrack():
    pass

@_api_function
def RPR_MIDI_CountEvts():
    pass

@_api_function
def RPR_MIDI_DeleteCC():
    pass

@_api_function
def RPR_MIDI_DeleteEvt():
    pass

@_api_function
def RPR_MIDI_DeleteNote():
    pass

@_api_function
def RPR_MIDI_DeleteTextSysexEvt():
    pass

@_api_function
def RPR_MIDI_EnumSelCC():
    pass

@_api_function
def RPR_MIDI_EnumSelEvts():
    pass

@_api_function
def RPR_MIDI_EnumSelNotes():
    pass

@_api_function
def RPR_MIDI_EnumSelTextSysexEvts():
    pass

@_api_function
def RPR_MIDI_GetAllEvts():
    pass

@_api_function
def RPR_MIDI_GetCC():
    pass

@_api_function
def RPR_MIDI_GetEvt():
    pass

@_api_function
def RPR_MIDI_GetGrid():
    pass

@_api_function
def RPR_MIDI_GetHash():
    pass

@_api_function
def RPR_MIDI_GetNote():
    pass

@_api_function
def RPR_MIDI_GetPPQPos_EndOfMeasure():
    pass

@_api_function
def RPR_MIDI_GetPPQPos_StartOfMeasure():
    pass

@_api_function
def RPR_MIDI_GetPPQPosFromProjQN():
    pass

@_api_function
def RPR_MIDI_GetPPQPosFromProjTime():
    pass

@_api_function
def RPR_MIDI_GetProjQNFromPPQPos():
    pass

@_api_function
def RPR_MIDI_GetProjTimeFromPPQPos():
    pass

@_api_function
def RPR_MIDI_GetScale():
    pass

@_api_function
def RPR_MIDI_GetTextSysexEvt():
    pass

@_api_function
def RPR_MIDI_GetTrackHash():
    pass

@_api_function
def RPR_MIDI_InsertCC():
    pass

@_api_function
def RPR_MIDI_InsertEvt():
    pass

@_api_function
def RPR_MIDI_InsertNote():
    pass

@_api_function
def RPR_MIDI_InsertTextSysexEvt():
    pass

@_api_function
def RPR_midi_reinit():
    pass

@_api_function
def RPR_MIDI_SelectAll():
    pass

@_api_function
def RPR_MIDI_SetAllEvts():
    pass

@_api_function
def RPR_MIDI_SetCC():
    pass

@_api_function
def RPR_MIDI_SetEvt():
    pass

@_api_function
def RPR_MIDI_SetItemExtents():
    pass

@_api_function
def RPR_MIDI_SetNote():
    pass

@_api_function
def RPR_MIDI_SetTextSysexEvt():
    pass

@_api_function
def RPR_MIDI_Sort():
    pass

@_api_function
def RPR_MIDIEditor_GetActive():
    pass

@_api_function
def RPR_MIDIEditor_GetMode():
    pass

@_api_function
def RPR_MIDIEditor_GetSetting_int():
    pass

@_api_function
def RPR_MIDIEditor_GetSetting_str():
    pass

@_api_function
def RPR_MIDIEditor_GetTake():
    pass

@_api_function
def RPR_MIDIEditor_LastFocused_OnCommand():
    pass

@_api_function
def RPR_MIDIEditor_OnCommand():
    pass

@_api_function
def RPR_mkpanstr():
    pass

@_api_function
def RPR_mkvolpanstr():
    pass

@_api_function
def RPR_mkvolstr():
    pass

@_api_function
def RPR_MoveEditCursor():
    pass

@_api_function
def RPR_MoveMediaItemToTrack():
    pass

@_api_function
def RPR_MuteAllTracks():
    pass

@_api_function
def RPR_my_getViewport():
    pass

@_api_function
def RPR_NamedCommandLookup():
    pass

@_api_function
def RPR_OnPauseButton():
    pass

@_api_function
def RPR_OnPauseButtonEx():
    pass

@_api_function
def RPR_OnPlayButton():
    pass

@_api_function
def RPR_OnPlayButtonEx():
    pass

@_api_function
def RPR_OnStopButton():
    pass

@_api_function
def RPR_OnStopButtonEx():
    pass

@_api_function
def RPR_OpenColorThemeFile():
    pass

@_api_function
def RPR_OpenMediaExplorer():
    pass

@_api_function
def RPR_OscLocalMessageToHost():
    pass

@_api_function
def RPR_parse_timestr():
    pass

@_api_function
def RPR_parse_timestr_len():
    pass

@_api_function
def RPR_parse_timestr_pos():
    pass

@_api_function
def RPR_parsepanstr():
    pass

@_api_function
def RPR_PCM_Sink_Enum():
    pass

@_api_function
def RPR_PCM_Sink_GetExtension():
    pass

@_api_function
def RPR_PCM_Sink_ShowConfig():
    pass

@_api_function
def RPR_PCM_Source_CreateFromFile():
    pass

@_api_function
def RPR_PCM_Source_CreateFromFileEx():
    pass

@_api_function
def RPR_PCM_Source_CreateFromType():
    pass

@_api_function
def RPR_PCM_Source_Destroy():
    pass

@_api_function
def RPR_PCM_Source_GetPeaks():
    pass

@_api_function
def RPR_PCM_Source_GetSectionInfo():
    pass

@_api_function
def RPR_PluginWantsAlwaysRunFx():
    pass

@_api_function
def RPR_PreventUIRefresh():
    pass

@_api_function
def RPR_ReaScriptError():
    pass

@_api_function
def RPR_RecursiveCreateDirectory():
    pass

@_api_function
def RPR_RefreshToolbar():
    pass

@_api_function
def RPR_RefreshToolbar2():
    pass

@_api_function
def RPR_relative_fn():
    pass

@_api_function
def RPR_RemoveTrackSend():
    pass

@_api_function
def RPR_RenderFileSection():
    pass

@_api_function
def RPR_ReorderSelectedTracks():
    pass

@_api_function
def RPR_Resample_EnumModes():
    pass

@_api_function
def RPR_resolve_fn():
    pass

@_api_function
def RPR_resolve_fn2():
    pass

@_api_function
def RPR_ReverseNamedCommandLookup():
    pass

@_api_function
def RPR_ScaleFromEnvelopeMode():
    pass

@_api_function
def RPR_ScaleToEnvelopeMode():
    pass

@_api_function
def RPR_SelectAllMediaItems():
    pass

@_api_function
def RPR_SelectProjectInstance():
    pass

@_api_function
def RPR_SetActiveTake():
    pass

@_api_function
def RPR_SetAutomationMode():
    pass

@_api_function
def RPR_SetCurrentBPM():
    pass

@_api_function
def RPR_SetCursorContext():
    pass

@_api_function
def RPR_SetEditCurPos():
    pass

@_api_function
def RPR_SetEditCurPos2():
    pass

@_api_function
def RPR_SetEnvelopePoint():
    pass

@_api_function
def RPR_SetEnvelopePointEx():
    pass

@_api_function
def RPR_SetEnvelopeStateChunk():
    pass

@_api_function
def RPR_SetExtState():
    pass

@_api_function
def RPR_SetGlobalAutomationOverride():
    pass

@_api_function
def RPR_SetItemStateChunk():
    pass

@_api_function
def RPR_SetMasterTrackVisibility():
    pass

@_api_function
def RPR_SetMediaItemInfo_Value():
    pass

@_api_function
def RPR_SetMediaItemLength():
    pass

@_api_function
def RPR_SetMediaItemPosition():
    pass

@_api_function
def RPR_SetMediaItemSelected():
    pass

@_api_function
def RPR_SetMediaItemTake_Source():
    pass

@_api_function
def RPR_SetMediaItemTakeInfo_Value():
    pass

@_api_function
def RPR_SetMediaTrackInfo_Value():
    pass

@_api_function
def RPR_SetMIDIEditorGrid():
    pass

@_api_function
def RPR_SetMixerScroll():
    pass

@_api_function
def RPR_SetMouseModifier():
    pass

@_api_function
def RPR_SetOnlyTrackSelected():
    pass

@_api_function
def RPR_SetProjectGrid():
    pass

@_api_function
def RPR_SetProjectMarker():
    pass

@_api_function
def RPR_SetProjectMarker2():
    pass

@_api_function
def RPR_SetProjectMarker3():
    pass

@_api_function
def RPR_SetProjectMarker4():
    pass

@_api_function
def RPR_SetProjectMarkerByIndex():
    pass

@_api_function
def RPR_SetProjectMarkerByIndex2():
    pass

@_api_function
def RPR_SetProjExtState():
    pass

@_api_function
def RPR_SetRegionRenderMatrix():
    pass

@_api_function
def RPR_SetTakeStretchMarker():
    pass

@_api_function
def RPR_SetTakeStretchMarkerSlope():
    pass

@_api_function
def RPR_SetTempoTimeSigMarker():
    pass

@_api_function
def RPR_SetToggleCommandState():
    pass

@_api_function
def RPR_SetTrackAutomationMode():
    pass

@_api_function
def RPR_SetTrackColor():
    pass

@_api_function
def RPR_SetTrackMIDILyrics():
    pass

@_api_function
def RPR_SetTrackMIDINoteName():
    pass

@_api_function
def RPR_SetTrackMIDINoteNameEx():
    pass

@_api_function
def RPR_SetTrackSelected():
    pass

@_api_function
def RPR_SetTrackSendInfo_Value():
    pass

@_api_function
def RPR_SetTrackSendUIPan():
    pass

@_api_function
def RPR_SetTrackSendUIVol():
    pass

@_api_function
def RPR_SetTrackStateChunk():
    pass

@_api_function
def RPR_ShowActionList():
    pass

@_api_function
def RPR_ShowConsoleMsg():
    pass

@_api_function
def RPR_ShowMessageBox():
    pass

@_api_function
def RPR_ShowPopupMenu():
    pass

@_api_function
def RPR_SLIDER2DB():
    pass

@_api_function
def RPR_SnapToGrid():
    pass

@_api_function
def RPR_SoloAllTracks():
    pass

@_api_function
def RPR_Splash_GetWnd():
    pass

@_api_function
def RPR_SplitMediaItem():
    pass

@_api_function
def RPR_stringToGuid():
    pass

@_api_function
def RPR_StuffMIDIMessage():
    pass

@_api_function
def RPR_TakeFX_AddByName():
    pass

@_api_function
def RPR_TakeFX_CopyToTake():
    pass

@_api_function
def RPR_TakeFX_CopyToTrack():
    pass

@_api_function
def RPR_TakeFX_Delete():
    pass

@_api_function
def RPR_TakeFX_EndParamEdit():
    pass

@_api_function
def RPR_TakeFX_FormatParamValue():
    pass

@_api_function
def RPR_TakeFX_FormatParamValueNormalized():
    pass

@_api_function
def RPR_TakeFX_GetChainVisible():
    pass

@_api_function
def RPR_TakeFX_GetCount():
    pass

@_api_function
def RPR_TakeFX_GetEnabled():
    pass

@_api_function
def RPR_TakeFX_GetEnvelope():
    pass

@_api_function
def RPR_TakeFX_GetFloatingWindow():
    pass

@_api_function
def RPR_TakeFX_GetFormattedParamValue():
    pass

@_api_function
def RPR_TakeFX_GetFXGUID():
    pass

@_api_function
def RPR_TakeFX_GetFXName():
    pass

@_api_function
def RPR_TakeFX_GetIOSize():
    pass

@_api_function
def RPR_TakeFX_GetNamedConfigParm():
    pass

@_api_function
def RPR_TakeFX_GetNumParams():
    pass

@_api_function
def RPR_TakeFX_GetOffline():
    pass

@_api_function
def RPR_TakeFX_GetOpen():
    pass

@_api_function
def RPR_TakeFX_GetParam():
    pass

@_api_function
def RPR_TakeFX_GetParameterStepSizes():
    pass

@_api_function
def RPR_TakeFX_GetParamEx():
    pass

@_api_function
def RPR_TakeFX_GetParamName():
    pass

@_api_function
def RPR_TakeFX_GetParamNormalized():
    pass

@_api_function
def RPR_TakeFX_GetPinMappings():
    pass

@_api_function
def RPR_TakeFX_GetPreset():
    pass

@_api_function
def RPR_TakeFX_GetPresetIndex():
    pass

@_api_function
def RPR_TakeFX_GetUserPresetFilename():
    pass

@_api_function
def RPR_TakeFX_NavigatePresets():
    pass

@_api_function
def RPR_TakeFX_SetEnabled():
    pass

@_api_function
def RPR_TakeFX_SetNamedConfigParm():
    pass

@_api_function
def RPR_TakeFX_SetOffline():
    pass

@_api_function
def RPR_TakeFX_SetOpen():
    pass

@_api_function
def RPR_TakeFX_SetParam():
    pass

@_api_function
def RPR_TakeFX_SetParamNormalized():
    pass

@_api_function
def RPR_TakeFX_SetPinMappings():
    pass

@_api_function
def RPR_TakeFX_SetPreset():
    pass

@_api_function
def RPR_TakeFX_SetPresetByIndex():
    pass

@_api_function
def RPR_TakeFX_Show():
    pass

@_api_function
def RPR_TakeIsMIDI():
    pass

@_api_function
def RPR_time_precise():
    pass

@_api_function
def RPR_TimeMap2_beatsToTime():
    pass

@_api_function
def RPR_TimeMap2_GetDividedBpmAtTime():
    pass

@_api_function
def RPR_TimeMap2_GetNextChangeTime():
    pass

@_api_function
def RPR_TimeMap2_QNToTime():
    pass

@_api_function
def RPR_TimeMap2_timeToBeats():
    pass

@_api_function
def RPR_TimeMap2_timeToQN():
    pass

@_api_function
def RPR_TimeMap_curFrameRate():
    pass

@_api_function
def RPR_TimeMap_GetDividedBpmAtTime():
    pass

@_api_function
def RPR_TimeMap_GetMeasureInfo():
    pass

@_api_function
def RPR_TimeMap_GetMetronomePattern():
    pass

@_api_function
def RPR_TimeMap_GetTimeSigAtTime():
    pass

@_api_function
def RPR_TimeMap_QNToMeasures():
    pass

@_api_function
def RPR_TimeMap_QNToTime():
    pass

@_api_function
def RPR_TimeMap_QNToTime_abs():
    pass

@_api_function
def RPR_TimeMap_timeToQN():
    pass

@_api_function
def RPR_TimeMap_timeToQN_abs():
    pass

@_api_function
def RPR_ToggleTrackSendUIMute():
    pass

@_api_function
def RPR_Track_GetPeakHoldDB():
    pass

@_api_function
def RPR_Track_GetPeakInfo():
    pass

@_api_function
def RPR_TrackCtl_SetToolTip():
    pass

@_api_function
def RPR_TrackFX_AddByName():
    pass

@_api_function
def RPR_TrackFX_CopyToTake():
    pass

@_api_function
def RPR_TrackFX_CopyToTrack():
    pass

@_api_function
def RPR_TrackFX_Delete():
    pass

@_api_function
def RPR_TrackFX_EndParamEdit():
    pass

@_api_function
def RPR_TrackFX_FormatParamValue():
    pass

@_api_function
def RPR_TrackFX_FormatParamValueNormalized():
    pass

@_api_function
def RPR_TrackFX_GetByName():
    pass

@_api_function
def RPR_TrackFX_GetChainVisible():
    pass

@_api_function
def RPR_TrackFX_GetCount():
    pass

@_api_function
def RPR_TrackFX_GetEnabled():
    pass

@_api_function
def RPR_TrackFX_GetEQ():
    pass

@_api_function
def RPR_TrackFX_GetEQBandEnabled():
    pass

@_api_function
def RPR_TrackFX_GetEQParam():
    pass

@_api_function
def RPR_TrackFX_GetFloatingWindow():
    pass

@_api_function
def RPR_TrackFX_GetFormattedParamValue():
    pass

@_api_function
def RPR_TrackFX_GetFXGUID():
    pass

@_api_function
def RPR_TrackFX_GetFXName():
    pass

@_api_function
def RPR_TrackFX_GetInstrument():
    pass

@_api_function
def RPR_TrackFX_GetIOSize():
    pass

@_api_function
def RPR_TrackFX_GetNamedConfigParm():
    pass

@_api_function
def RPR_TrackFX_GetNumParams():
    pass

@_api_function
def RPR_TrackFX_GetOffline():
    pass

@_api_function
def RPR_TrackFX_GetOpen():
    pass

@_api_function
def RPR_TrackFX_GetParam():
    pass

@_api_function
def RPR_TrackFX_GetParameterStepSizes():
    pass

@_api_function
def RPR_TrackFX_GetParamEx():
    pass

@_api_function
def RPR_TrackFX_GetParamName():
    pass

@_api_function
def RPR_TrackFX_GetParamNormalized():
    pass

@_api_function
def RPR_TrackFX_GetPinMappings():
    pass

@_api_function
def RPR_TrackFX_GetPreset():
    pass

@_api_function
def RPR_TrackFX_GetPresetIndex():
    pass

@_api_function
def RPR_TrackFX_GetRecChainVisible():
    pass

@_api_function
def RPR_TrackFX_GetRecCount():
    pass

@_api_function
def RPR_TrackFX_GetUserPresetFilename():
    pass

@_api_function
def RPR_TrackFX_NavigatePresets():
    pass

@_api_function
def RPR_TrackFX_SetEnabled():
    pass

@_api_function
def RPR_TrackFX_SetEQBandEnabled():
    pass

@_api_function
def RPR_TrackFX_SetEQParam():
    pass

@_api_function
def RPR_TrackFX_SetNamedConfigParm():
    pass

@_api_function
def RPR_TrackFX_SetOffline():
    pass

@_api_function
def RPR_TrackFX_SetOpen():
    pass

@_api_function
def RPR_TrackFX_SetParam():
    pass

@_api_function
def RPR_TrackFX_SetParamNormalized():
    pass

@_api_function
def RPR_TrackFX_SetPinMappings():
    pass

@_api_function
def RPR_TrackFX_SetPreset():
    pass

@_api_function
def RPR_TrackFX_SetPresetByIndex():
    pass

@_api_function
def RPR_TrackFX_Show():
    pass

@_api_function
def RPR_TrackList_AdjustWindows():
    pass

@_api_function
def RPR_TrackList_UpdateAllExternalSurfaces():
    pass

@_api_function
def RPR_Undo_BeginBlock():
    pass

@_api_function
def RPR_Undo_BeginBlock2():
    pass

@_api_function
def RPR_Undo_CanRedo2():
    pass

@_api_function
def RPR_Undo_CanUndo2():
    pass

@_api_function
def RPR_Undo_DoRedo2():
    pass

@_api_function
def RPR_Undo_DoUndo2():
    pass

@_api_function
def RPR_Undo_EndBlock():
    pass

@_api_function
def RPR_Undo_EndBlock2():
    pass

@_api_function
def RPR_Undo_OnStateChange():
    pass

@_api_function
def RPR_Undo_OnStateChange2():
    pass

@_api_function
def RPR_Undo_OnStateChange_Item():
    pass

@_api_function
def RPR_Undo_OnStateChangeEx():
    pass

@_api_function
def RPR_Undo_OnStateChangeEx2():
    pass

@_api_function
def RPR_UpdateArrange():
    pass

@_api_function
def RPR_UpdateItemInProject():
    pass

@_api_function
def RPR_UpdateTimeline():
    pass

@_api_function
def RPR_ValidatePtr():
    pass

@_api_function
def RPR_ValidatePtr2():
    pass

@_api_function
def RPR_ViewPrefs():
    pass

